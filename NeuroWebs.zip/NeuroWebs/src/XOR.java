
public class XOR {
	double h1i, h1o, h2i, h2o, w1 = 0.45, w2 = 0.78, w3 = -0.12, w4 = 0.13, w5 = 1.5, w6 = -2.3, oi, delo, delH1, delH2,
			gradw1, gradw2, gradw3, gradw4, gradw5, gradw6;
	static double delw5, delw1, delw2, delw3, delw4, delw6, delw1pred = 0, delw2pred = 0, delw3pred = 0, delw4pred = 0,
			delw5pred = 0, delw6pred = 0, oo, ideal = 1;

	public static void main(String[] args) {
		XOR x = new XOR();
		for (int i = 0; i < 50; i++) {
			x.forwardPropagation(1, 0);
			x.error(ideal, oo);
			x.backwardpropagation();
			delw1pred = delw1;
			delw2pred = delw2;
			delw3pred = delw3;
			delw4pred = delw4;
			delw5pred = delw5;
			delw6pred = delw6;

		}
	}

	private double forwardPropagation(int i1, int i2) {
		// XOR x = new XOR();
		h1i = (i1 * w1) + (i2 * w3);
		h2i = (i1 * w2) + (i2 * w4);
		h1o = XOR.sigmoid1(h1i);
		h2o = XOR.sigmoid1(h2i);
		oi = (h1o * w5) + (h2o * w6);
		oo = XOR.sigmoid1(oi);
		System.out.println(oo);
		int n = 1;
		n++;
		return oo;
	}

	private double error(double x, double y) {
		int z = (int) ((Math.pow(ideal - oo, 2) / 1) * 100);
		System.out.println("Error is " + z + "%");
		return z;
	}

	private void backwardpropagation() {
		double E = 0.7;
		double A = 0.3;
		delo = (ideal - oo) * ((ideal - oo) * oo);
		delH1 = ((ideal - h1o) * h1o) * (w5 * delo);
		gradw5 = h1o * delo;
		delw5 = E * gradw5 + delw5pred * A;
		w5 += delw5;
		delH2 = ((ideal - h2o) * h2o) * (w6 * delo);
		gradw6 = h2o * delo;
		delw6 = E * gradw6 + delw6pred * A;
		w6 += delw6;
		gradw1 = 1 * delH1;
		delw1 = E * gradw1 + delw1pred * A;
		w1 += delw1;

		gradw2 = 1 * delH2;
		delw2 = E * gradw2 + delw2pred * A;
		w2 += delw2;

		gradw3 = 0 * delH1;
		delw3 = E * gradw3 + delw3pred * A;
		w3 += delw3;

		gradw4 = 0 * delH2;
		delw4 = E * gradw4 + delw4pred * A;
		w4 += delw4;
		System.out.println(w1 + " " + w2 + " " + w3 + " " + w4);

		// return w1,w2,w3,w4,w5,w6;
	}

	private static double sigmoid1(double x) {
		double ans = 1 / (1 + Math.exp(-x));
		return ans;

	}

}
